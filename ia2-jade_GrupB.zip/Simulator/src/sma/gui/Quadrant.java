package sma.gui;

public class Quadrant {
	public int x1;
	public int x2;
	public int y1;
	public int y2;
	
	public Quadrant(int x, int x2, int y, int y2) {
		this.x1 = x;
		this.x2 = x2;
		this.y1 = y;
		this.y2 = y2;
	}
}
